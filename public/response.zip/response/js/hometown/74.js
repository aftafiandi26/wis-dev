[
    {
      "id": "7401",
      "province_id": "74",
      "name": "KABUPATEN BUTON"
    },
    {
      "id": "7402",
      "province_id": "74",
      "name": "KABUPATEN MUNA"
    },
    {
      "id": "7403",
      "province_id": "74",
      "name": "KABUPATEN KONAWE"
    },
    {
      "id": "7404",
      "province_id": "74",
      "name": "KABUPATEN KOLAKA"
    },
    {
      "id": "7405",
      "province_id": "74",
      "name": "KABUPATEN KONAWE SELATAN"
    },
    {
      "id": "7406",
      "province_id": "74",
      "name": "KABUPATEN BOMBANA"
    },
    {
      "id": "7407",
      "province_id": "74",
      "name": "KABUPATEN WAKATOBI"
    },
    {
      "id": "7408",
      "province_id": "74",
      "name": "KABUPATEN KOLAKA UTARA"
    },
    {
      "id": "7409",
      "province_id": "74",
      "name": "KABUPATEN BUTON UTARA"
    },
    {
      "id": "7410",
      "province_id": "74",
      "name": "KABUPATEN KONAWE UTARA"
    },
    {
      "id": "7411",
      "province_id": "74",
      "name": "KABUPATEN KOLAKA TIMUR"
    },
    {
      "id": "7412",
      "province_id": "74",
      "name": "KABUPATEN KONAWE KEPULAUAN"
    },
    {
      "id": "7413",
      "province_id": "74",
      "name": "KABUPATEN MUNA BARAT"
    },
    {
      "id": "7414",
      "province_id": "74",
      "name": "KABUPATEN BUTON TENGAH"
    },
    {
      "id": "7415",
      "province_id": "74",
      "name": "KABUPATEN BUTON SELATAN"
    },
    {
      "id": "7471",
      "province_id": "74",
      "name": "KOTA KENDARI"
    },
    {
      "id": "7472",
      "province_id": "74",
      "name": "KOTA BAUBAU"
    }
  ]