[
    {
      "id": "6401",
      "province_id": "64",
      "name": "KABUPATEN PASER"
    },
    {
      "id": "6402",
      "province_id": "64",
      "name": "KABUPATEN KUTAI BARAT"
    },
    {
      "id": "6403",
      "province_id": "64",
      "name": "KABUPATEN KUTAI KARTANEGARA"
    },
    {
      "id": "6404",
      "province_id": "64",
      "name": "KABUPATEN KUTAI TIMUR"
    },
    {
      "id": "6405",
      "province_id": "64",
      "name": "KABUPATEN BERAU"
    },
    {
      "id": "6409",
      "province_id": "64",
      "name": "KABUPATEN PENAJAM PASER UTARA"
    },
    {
      "id": "6411",
      "province_id": "64",
      "name": "KABUPATEN MAHAKAM HULU"
    },
    {
      "id": "6471",
      "province_id": "64",
      "name": "KOTA BALIKPAPAN"
    },
    {
      "id": "6472",
      "province_id": "64",
      "name": "KOTA SAMARINDA"
    },
    {
      "id": "6474",
      "province_id": "64",
      "name": "KOTA BONTANG"
    }
  ]