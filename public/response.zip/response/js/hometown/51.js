[
    {
      "id": "5101",
      "province_id": "51",
      "name": "KABUPATEN JEMBRANA"
    },
    {
      "id": "5102",
      "province_id": "51",
      "name": "KABUPATEN TABANAN"
    },
    {
      "id": "5103",
      "province_id": "51",
      "name": "KABUPATEN BADUNG"
    },
    {
      "id": "5104",
      "province_id": "51",
      "name": "KABUPATEN GIANYAR"
    },
    {
      "id": "5105",
      "province_id": "51",
      "name": "KABUPATEN KLUNGKUNG"
    },
    {
      "id": "5106",
      "province_id": "51",
      "name": "KABUPATEN BANGLI"
    },
    {
      "id": "5107",
      "province_id": "51",
      "name": "KABUPATEN KARANG ASEM"
    },
    {
      "id": "5108",
      "province_id": "51",
      "name": "KABUPATEN BULELENG"
    },
    {
      "id": "5171",
      "province_id": "51",
      "name": "KOTA DENPASAR"
    }
  ]