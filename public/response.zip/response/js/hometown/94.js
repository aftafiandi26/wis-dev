[
    {
      "id": "9401",
      "province_id": "94",
      "name": "KABUPATEN MERAUKE"
    },
    {
      "id": "9402",
      "province_id": "94",
      "name": "KABUPATEN JAYAWIJAYA"
    },
    {
      "id": "9403",
      "province_id": "94",
      "name": "KABUPATEN JAYAPURA"
    },
    {
      "id": "9404",
      "province_id": "94",
      "name": "KABUPATEN NABIRE"
    },
    {
      "id": "9408",
      "province_id": "94",
      "name": "KABUPATEN KEPULAUAN YAPEN"
    },
    {
      "id": "9409",
      "province_id": "94",
      "name": "KABUPATEN BIAK NUMFOR"
    },
    {
      "id": "9410",
      "province_id": "94",
      "name": "KABUPATEN PANIAI"
    },
    {
      "id": "9411",
      "province_id": "94",
      "name": "KABUPATEN PUNCAK JAYA"
    },
    {
      "id": "9412",
      "province_id": "94",
      "name": "KABUPATEN MIMIKA"
    },
    {
      "id": "9413",
      "province_id": "94",
      "name": "KABUPATEN BOVEN DIGOEL"
    },
    {
      "id": "9414",
      "province_id": "94",
      "name": "KABUPATEN MAPPI"
    },
    {
      "id": "9415",
      "province_id": "94",
      "name": "KABUPATEN ASMAT"
    },
    {
      "id": "9416",
      "province_id": "94",
      "name": "KABUPATEN YAHUKIMO"
    },
    {
      "id": "9417",
      "province_id": "94",
      "name": "KABUPATEN PEGUNUNGAN BINTANG"
    },
    {
      "id": "9418",
      "province_id": "94",
      "name": "KABUPATEN TOLIKARA"
    },
    {
      "id": "9419",
      "province_id": "94",
      "name": "KABUPATEN SARMI"
    },
    {
      "id": "9420",
      "province_id": "94",
      "name": "KABUPATEN KEEROM"
    },
    {
      "id": "9426",
      "province_id": "94",
      "name": "KABUPATEN WAROPEN"
    },
    {
      "id": "9427",
      "province_id": "94",
      "name": "KABUPATEN SUPIORI"
    },
    {
      "id": "9428",
      "province_id": "94",
      "name": "KABUPATEN MAMBERAMO RAYA"
    },
    {
      "id": "9429",
      "province_id": "94",
      "name": "KABUPATEN NDUGA"
    },
    {
      "id": "9430",
      "province_id": "94",
      "name": "KABUPATEN LANNY JAYA"
    },
    {
      "id": "9431",
      "province_id": "94",
      "name": "KABUPATEN MAMBERAMO TENGAH"
    },
    {
      "id": "9432",
      "province_id": "94",
      "name": "KABUPATEN YALIMO"
    },
    {
      "id": "9433",
      "province_id": "94",
      "name": "KABUPATEN PUNCAK"
    },
    {
      "id": "9434",
      "province_id": "94",
      "name": "KABUPATEN DOGIYAI"
    },
    {
      "id": "9435",
      "province_id": "94",
      "name": "KABUPATEN INTAN JAYA"
    },
    {
      "id": "9436",
      "province_id": "94",
      "name": "KABUPATEN DEIYAI"
    },
    {
      "id": "9471",
      "province_id": "94",
      "name": "KOTA JAYAPURA"
    }
  ]