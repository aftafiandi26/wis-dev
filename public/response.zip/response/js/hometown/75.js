[
    {
      "id": "7501",
      "province_id": "75",
      "name": "KABUPATEN BOALEMO"
    },
    {
      "id": "7502",
      "province_id": "75",
      "name": "KABUPATEN GORONTALO"
    },
    {
      "id": "7503",
      "province_id": "75",
      "name": "KABUPATEN POHUWATO"
    },
    {
      "id": "7504",
      "province_id": "75",
      "name": "KABUPATEN BONE BOLANGO"
    },
    {
      "id": "7505",
      "province_id": "75",
      "name": "KABUPATEN GORONTALO UTARA"
    },
    {
      "id": "7571",
      "province_id": "75",
      "name": "KOTA GORONTALO"
    }
  ]