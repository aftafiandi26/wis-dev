[
    {
      "id": "7301",
      "province_id": "73",
      "name": "KABUPATEN KEPULAUAN SELAYAR"
    },
    {
      "id": "7302",
      "province_id": "73",
      "name": "KABUPATEN BULUKUMBA"
    },
    {
      "id": "7303",
      "province_id": "73",
      "name": "KABUPATEN BANTAENG"
    },
    {
      "id": "7304",
      "province_id": "73",
      "name": "KABUPATEN JENEPONTO"
    },
    {
      "id": "7305",
      "province_id": "73",
      "name": "KABUPATEN TAKALAR"
    },
    {
      "id": "7306",
      "province_id": "73",
      "name": "KABUPATEN GOWA"
    },
    {
      "id": "7307",
      "province_id": "73",
      "name": "KABUPATEN SINJAI"
    },
    {
      "id": "7308",
      "province_id": "73",
      "name": "KABUPATEN MAROS"
    },
    {
      "id": "7309",
      "province_id": "73",
      "name": "KABUPATEN PANGKAJENE DAN KEPULAUAN"
    },
    {
      "id": "7310",
      "province_id": "73",
      "name": "KABUPATEN BARRU"
    },
    {
      "id": "7311",
      "province_id": "73",
      "name": "KABUPATEN BONE"
    },
    {
      "id": "7312",
      "province_id": "73",
      "name": "KABUPATEN SOPPENG"
    },
    {
      "id": "7313",
      "province_id": "73",
      "name": "KABUPATEN WAJO"
    },
    {
      "id": "7314",
      "province_id": "73",
      "name": "KABUPATEN SIDENRENG RAPPANG"
    },
    {
      "id": "7315",
      "province_id": "73",
      "name": "KABUPATEN PINRANG"
    },
    {
      "id": "7316",
      "province_id": "73",
      "name": "KABUPATEN ENREKANG"
    },
    {
      "id": "7317",
      "province_id": "73",
      "name": "KABUPATEN LUWU"
    },
    {
      "id": "7318",
      "province_id": "73",
      "name": "KABUPATEN TANA TORAJA"
    },
    {
      "id": "7322",
      "province_id": "73",
      "name": "KABUPATEN LUWU UTARA"
    },
    {
      "id": "7325",
      "province_id": "73",
      "name": "KABUPATEN LUWU TIMUR"
    },
    {
      "id": "7326",
      "province_id": "73",
      "name": "KABUPATEN TORAJA UTARA"
    },
    {
      "id": "7371",
      "province_id": "73",
      "name": "KOTA MAKASSAR"
    },
    {
      "id": "7372",
      "province_id": "73",
      "name": "KOTA PAREPARE"
    },
    {
      "id": "7373",
      "province_id": "73",
      "name": "KOTA PALOPO"
    }
  ]