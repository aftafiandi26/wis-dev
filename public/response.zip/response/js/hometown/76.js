[
    {
      "id": "7601",
      "province_id": "76",
      "name": "KABUPATEN MAJENE"
    },
    {
      "id": "7602",
      "province_id": "76",
      "name": "KABUPATEN POLEWALI MANDAR"
    },
    {
      "id": "7603",
      "province_id": "76",
      "name": "KABUPATEN MAMASA"
    },
    {
      "id": "7604",
      "province_id": "76",
      "name": "KABUPATEN MAMUJU"
    },
    {
      "id": "7605",
      "province_id": "76",
      "name": "KABUPATEN MAMUJU UTARA"
    },
    {
      "id": "7606",
      "province_id": "76",
      "name": "KABUPATEN MAMUJU TENGAH"
    }
  ]