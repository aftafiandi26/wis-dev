[
    {
      "id": "1501",
      "province_id": "15",
      "name": "KABUPATEN KERINCI"
    },
    {
      "id": "1502",
      "province_id": "15",
      "name": "KABUPATEN MERANGIN"
    },
    {
      "id": "1503",
      "province_id": "15",
      "name": "KABUPATEN SAROLANGUN"
    },
    {
      "id": "1504",
      "province_id": "15",
      "name": "KABUPATEN BATANG HARI"
    },
    {
      "id": "1505",
      "province_id": "15",
      "name": "KABUPATEN MUARO JAMBI"
    },
    {
      "id": "1506",
      "province_id": "15",
      "name": "KABUPATEN TANJUNG JABUNG TIMUR"
    },
    {
      "id": "1507",
      "province_id": "15",
      "name": "KABUPATEN TANJUNG JABUNG BARAT"
    },
    {
      "id": "1508",
      "province_id": "15",
      "name": "KABUPATEN TEBO"
    },
    {
      "id": "1509",
      "province_id": "15",
      "name": "KABUPATEN BUNGO"
    },
    {
      "id": "1571",
      "province_id": "15",
      "name": "KOTA JAMBI"
    },
    {
      "id": "1572",
      "province_id": "15",
      "name": "KOTA SUNGAI PENUH"
    }
  ]