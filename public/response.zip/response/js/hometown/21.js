[
    {
      "id": "2101",
      "province_id": "21",
      "name": "KABUPATEN KARIMUN"
    },
    {
      "id": "2102",
      "province_id": "21",
      "name": "KABUPATEN BINTAN"
    },
    {
      "id": "2103",
      "province_id": "21",
      "name": "KABUPATEN NATUNA"
    },
    {
      "id": "2104",
      "province_id": "21",
      "name": "KABUPATEN LINGGA"
    },
    {
      "id": "2105",
      "province_id": "21",
      "name": "KABUPATEN KEPULAUAN ANAMBAS"
    },
    {
      "id": "2171",
      "province_id": "21",
      "name": "KOTA B A T A M"
    },
    {
      "id": "2172",
      "province_id": "21",
      "name": "KOTA TANJUNG PINANG"
    }
  ]