[
    {
      "id": "1901",
      "province_id": "19",
      "name": "KABUPATEN BANGKA"
    },
    {
      "id": "1902",
      "province_id": "19",
      "name": "KABUPATEN BELITUNG"
    },
    {
      "id": "1903",
      "province_id": "19",
      "name": "KABUPATEN BANGKA BARAT"
    },
    {
      "id": "1904",
      "province_id": "19",
      "name": "KABUPATEN BANGKA TENGAH"
    },
    {
      "id": "1905",
      "province_id": "19",
      "name": "KABUPATEN BANGKA SELATAN"
    },
    {
      "id": "1906",
      "province_id": "19",
      "name": "KABUPATEN BELITUNG TIMUR"
    },
    {
      "id": "1971",
      "province_id": "19",
      "name": "KOTA PANGKAL PINANG"
    }
  ]