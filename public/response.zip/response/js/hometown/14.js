[
    {
      "id": "1401",
      "province_id": "14",
      "name": "KABUPATEN KUANTAN SINGINGI"
    },
    {
      "id": "1402",
      "province_id": "14",
      "name": "KABUPATEN INDRAGIRI HULU"
    },
    {
      "id": "1403",
      "province_id": "14",
      "name": "KABUPATEN INDRAGIRI HILIR"
    },
    {
      "id": "1404",
      "province_id": "14",
      "name": "KABUPATEN PELALAWAN"
    },
    {
      "id": "1405",
      "province_id": "14",
      "name": "KABUPATEN S I A K"
    },
    {
      "id": "1406",
      "province_id": "14",
      "name": "KABUPATEN KAMPAR"
    },
    {
      "id": "1407",
      "province_id": "14",
      "name": "KABUPATEN ROKAN HULU"
    },
    {
      "id": "1408",
      "province_id": "14",
      "name": "KABUPATEN BENGKALIS"
    },
    {
      "id": "1409",
      "province_id": "14",
      "name": "KABUPATEN ROKAN HILIR"
    },
    {
      "id": "1410",
      "province_id": "14",
      "name": "KABUPATEN KEPULAUAN MERANTI"
    },
    {
      "id": "1471",
      "province_id": "14",
      "name": "KOTA PEKANBARU"
    },
    {
      "id": "1473",
      "province_id": "14",
      "name": "KOTA D U M A I"
    }
  ]