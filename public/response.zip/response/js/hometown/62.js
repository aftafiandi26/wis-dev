[
    {
      "id": "6201",
      "province_id": "62",
      "name": "KABUPATEN KOTAWARINGIN BARAT"
    },
    {
      "id": "6202",
      "province_id": "62",
      "name": "KABUPATEN KOTAWARINGIN TIMUR"
    },
    {
      "id": "6203",
      "province_id": "62",
      "name": "KABUPATEN KAPUAS"
    },
    {
      "id": "6204",
      "province_id": "62",
      "name": "KABUPATEN BARITO SELATAN"
    },
    {
      "id": "6205",
      "province_id": "62",
      "name": "KABUPATEN BARITO UTARA"
    },
    {
      "id": "6206",
      "province_id": "62",
      "name": "KABUPATEN SUKAMARA"
    },
    {
      "id": "6207",
      "province_id": "62",
      "name": "KABUPATEN LAMANDAU"
    },
    {
      "id": "6208",
      "province_id": "62",
      "name": "KABUPATEN SERUYAN"
    },
    {
      "id": "6209",
      "province_id": "62",
      "name": "KABUPATEN KATINGAN"
    },
    {
      "id": "6210",
      "province_id": "62",
      "name": "KABUPATEN PULANG PISAU"
    },
    {
      "id": "6211",
      "province_id": "62",
      "name": "KABUPATEN GUNUNG MAS"
    },
    {
      "id": "6212",
      "province_id": "62",
      "name": "KABUPATEN BARITO TIMUR"
    },
    {
      "id": "6213",
      "province_id": "62",
      "name": "KABUPATEN MURUNG RAYA"
    },
    {
      "id": "6271",
      "province_id": "62",
      "name": "KOTA PALANGKA RAYA"
    }
  ]