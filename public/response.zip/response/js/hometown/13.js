[
    {
      "id": "1301",
      "province_id": "13",
      "name": "KABUPATEN KEPULAUAN MENTAWAI"
    },
    {
      "id": "1302",
      "province_id": "13",
      "name": "KABUPATEN PESISIR SELATAN"
    },
    {
      "id": "1303",
      "province_id": "13",
      "name": "KABUPATEN SOLOK"
    },
    {
      "id": "1304",
      "province_id": "13",
      "name": "KABUPATEN SIJUNJUNG"
    },
    {
      "id": "1305",
      "province_id": "13",
      "name": "KABUPATEN TANAH DATAR"
    },
    {
      "id": "1306",
      "province_id": "13",
      "name": "KABUPATEN PADANG PARIAMAN"
    },
    {
      "id": "1307",
      "province_id": "13",
      "name": "KABUPATEN AGAM"
    },
    {
      "id": "1308",
      "province_id": "13",
      "name": "KABUPATEN LIMA PULUH KOTA"
    },
    {
      "id": "1309",
      "province_id": "13",
      "name": "KABUPATEN PASAMAN"
    },
    {
      "id": "1310",
      "province_id": "13",
      "name": "KABUPATEN SOLOK SELATAN"
    },
    {
      "id": "1311",
      "province_id": "13",
      "name": "KABUPATEN DHARMASRAYA"
    },
    {
      "id": "1312",
      "province_id": "13",
      "name": "KABUPATEN PASAMAN BARAT"
    },
    {
      "id": "1371",
      "province_id": "13",
      "name": "KOTA PADANG"
    },
    {
      "id": "1372",
      "province_id": "13",
      "name": "KOTA SOLOK"
    },
    {
      "id": "1373",
      "province_id": "13",
      "name": "KOTA SAWAH LUNTO"
    },
    {
      "id": "1374",
      "province_id": "13",
      "name": "KOTA PADANG PANJANG"
    },
    {
      "id": "1375",
      "province_id": "13",
      "name": "KOTA BUKITTINGGI"
    },
    {
      "id": "1376",
      "province_id": "13",
      "name": "KOTA PAYAKUMBUH"
    },
    {
      "id": "1377",
      "province_id": "13",
      "name": "KOTA PARIAMAN"
    }
  ]
