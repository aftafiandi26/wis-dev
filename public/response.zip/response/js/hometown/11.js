[
    {
        "id": "1101",
        "province_id": "11",
        "name": "KABUPATEN SIMEULUE"
    },
    {
        "id": "1102",
        "province_id": "11",
        "name": "KABUPATEN ACEH SINGKIL"
    },
    {
        "id": "1103",
        "province_id": "11",
        "name": "KABUPATEN ACEH SELATAN"
    },
    {
        "id": "1104",
        "province_id": "11",
        "name": "KABUPATEN ACEH TENGGARA"
    },
    {
        "id": "1105",
        "province_id": "11",
        "name": "KABUPATEN ACEH TIMUR"
    },
    {
        "id": "1106",
        "province_id": "11",
        "name": "KABUPATEN ACEH TENGAH"
    },
    {
        "id": "1107",
        "province_id": "11",
        "name": "KABUPATEN ACEH BARAT"
    },
    {
        "id": "1108",
        "province_id": "11",
        "name": "KABUPATEN ACEH BESAR"
    },
    {
        "id": "1109",
        "province_id": "11",
        "name": "KABUPATEN PIDIE"
    },
    {
        "id": "1110",
        "province_id": "11",
        "name": "KABUPATEN BIREUEN"
    },
    {
        "id": "1111",
        "province_id": "11",
        "name": "KABUPATEN ACEH UTARA"
    },
    {
        "id": "1112",
        "province_id": "11",
        "name": "KABUPATEN ACEH BARAT DAYA"
    },
    {
        "id": "1113",
        "province_id": "11",
        "name": "KABUPATEN GAYO LUES"
    },
    {
        "id": "1114",
        "province_id": "11",
        "name": "KABUPATEN ACEH TAMIANG"
    },
    {
        "id": "1115",
        "province_id": "11",
        "name": "KABUPATEN NAGAN RAYA"
    },
    {
        "id": "1116",
        "province_id": "11",
        "name": "KABUPATEN ACEH JAYA"
    },
    {
        "id": "1117",
        "province_id": "11",
        "name": "KABUPATEN BENER MERIAH"
    },
    {
        "id": "1118",
        "province_id": "11",
        "name": "KABUPATEN PIDIE JAYA"
    },
    {
        "id": "1171",
        "province_id": "11",
        "name": "KOTA BANDA ACEH"
    },
    {
        "id": "1172",
        "province_id": "11",
        "name": "KOTA SABANG"
    },
    {
        "id": "1173",
        "province_id": "11",
        "name": "KOTA LANGSA"
    },
    {
        "id": "1174",
        "province_id": "11",
        "name": "KOTA LHOKSEUMAWE"
    },
    {
        "id": "1175",
        "province_id": "11",
        "name": "KOTA SUBULUSSALAM"
    }
]