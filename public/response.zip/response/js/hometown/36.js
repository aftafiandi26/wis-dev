[
    {
      "id": "3601",
      "province_id": "36",
      "name": "KABUPATEN PANDEGLANG"
    },
    {
      "id": "3602",
      "province_id": "36",
      "name": "KABUPATEN LEBAK"
    },
    {
      "id": "3603",
      "province_id": "36",
      "name": "KABUPATEN TANGERANG"
    },
    {
      "id": "3604",
      "province_id": "36",
      "name": "KABUPATEN SERANG"
    },
    {
      "id": "3671",
      "province_id": "36",
      "name": "KOTA TANGERANG"
    },
    {
      "id": "3672",
      "province_id": "36",
      "name": "KOTA CILEGON"
    },
    {
      "id": "3673",
      "province_id": "36",
      "name": "KOTA SERANG"
    },
    {
      "id": "3674",
      "province_id": "36",
      "name": "KOTA TANGERANG SELATAN"
    }
  ]