[
    {
      "id": "3401",
      "province_id": "34",
      "name": "KABUPATEN KULON PROGO"
    },
    {
      "id": "3402",
      "province_id": "34",
      "name": "KABUPATEN BANTUL"
    },
    {
      "id": "3403",
      "province_id": "34",
      "name": "KABUPATEN GUNUNG KIDUL"
    },
    {
      "id": "3404",
      "province_id": "34",
      "name": "KABUPATEN SLEMAN"
    },
    {
      "id": "3471",
      "province_id": "34",
      "name": "KOTA YOGYAKARTA"
    }
  ]