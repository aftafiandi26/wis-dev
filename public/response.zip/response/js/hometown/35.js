[
    {
      "id": "3501",
      "province_id": "35",
      "name": "KABUPATEN PACITAN"
    },
    {
      "id": "3502",
      "province_id": "35",
      "name": "KABUPATEN PONOROGO"
    },
    {
      "id": "3503",
      "province_id": "35",
      "name": "KABUPATEN TRENGGALEK"
    },
    {
      "id": "3504",
      "province_id": "35",
      "name": "KABUPATEN TULUNGAGUNG"
    },
    {
      "id": "3505",
      "province_id": "35",
      "name": "KABUPATEN BLITAR"
    },
    {
      "id": "3506",
      "province_id": "35",
      "name": "KABUPATEN KEDIRI"
    },
    {
      "id": "3507",
      "province_id": "35",
      "name": "KABUPATEN MALANG"
    },
    {
      "id": "3508",
      "province_id": "35",
      "name": "KABUPATEN LUMAJANG"
    },
    {
      "id": "3509",
      "province_id": "35",
      "name": "KABUPATEN JEMBER"
    },
    {
      "id": "3510",
      "province_id": "35",
      "name": "KABUPATEN BANYUWANGI"
    },
    {
      "id": "3511",
      "province_id": "35",
      "name": "KABUPATEN BONDOWOSO"
    },
    {
      "id": "3512",
      "province_id": "35",
      "name": "KABUPATEN SITUBONDO"
    },
    {
      "id": "3513",
      "province_id": "35",
      "name": "KABUPATEN PROBOLINGGO"
    },
    {
      "id": "3514",
      "province_id": "35",
      "name": "KABUPATEN PASURUAN"
    },
    {
      "id": "3515",
      "province_id": "35",
      "name": "KABUPATEN SIDOARJO"
    },
    {
      "id": "3516",
      "province_id": "35",
      "name": "KABUPATEN MOJOKERTO"
    },
    {
      "id": "3517",
      "province_id": "35",
      "name": "KABUPATEN JOMBANG"
    },
    {
      "id": "3518",
      "province_id": "35",
      "name": "KABUPATEN NGANJUK"
    },
    {
      "id": "3519",
      "province_id": "35",
      "name": "KABUPATEN MADIUN"
    },
    {
      "id": "3520",
      "province_id": "35",
      "name": "KABUPATEN MAGETAN"
    },
    {
      "id": "3521",
      "province_id": "35",
      "name": "KABUPATEN NGAWI"
    },
    {
      "id": "3522",
      "province_id": "35",
      "name": "KABUPATEN BOJONEGORO"
    },
    {
      "id": "3523",
      "province_id": "35",
      "name": "KABUPATEN TUBAN"
    },
    {
      "id": "3524",
      "province_id": "35",
      "name": "KABUPATEN LAMONGAN"
    },
    {
      "id": "3525",
      "province_id": "35",
      "name": "KABUPATEN GRESIK"
    },
    {
      "id": "3526",
      "province_id": "35",
      "name": "KABUPATEN BANGKALAN"
    },
    {
      "id": "3527",
      "province_id": "35",
      "name": "KABUPATEN SAMPANG"
    },
    {
      "id": "3528",
      "province_id": "35",
      "name": "KABUPATEN PAMEKASAN"
    },
    {
      "id": "3529",
      "province_id": "35",
      "name": "KABUPATEN SUMENEP"
    },
    {
      "id": "3571",
      "province_id": "35",
      "name": "KOTA KEDIRI"
    },
    {
      "id": "3572",
      "province_id": "35",
      "name": "KOTA BLITAR"
    },
    {
      "id": "3573",
      "province_id": "35",
      "name": "KOTA MALANG"
    },
    {
      "id": "3574",
      "province_id": "35",
      "name": "KOTA PROBOLINGGO"
    },
    {
      "id": "3575",
      "province_id": "35",
      "name": "KOTA PASURUAN"
    },
    {
      "id": "3576",
      "province_id": "35",
      "name": "KOTA MOJOKERTO"
    },
    {
      "id": "3577",
      "province_id": "35",
      "name": "KOTA MADIUN"
    },
    {
      "id": "3578",
      "province_id": "35",
      "name": "KOTA SURABAYA"
    },
    {
      "id": "3579",
      "province_id": "35",
      "name": "KOTA BATU"
    }
  ]