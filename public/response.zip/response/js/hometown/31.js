[
    {
      "id": "3101",
      "province_id": "31",
      "name": "KABUPATEN KEPULAUAN SERIBU"
    },
    {
      "id": "3171",
      "province_id": "31",
      "name": "KOTA JAKARTA SELATAN"
    },
    {
      "id": "3172",
      "province_id": "31",
      "name": "KOTA JAKARTA TIMUR"
    },
    {
      "id": "3173",
      "province_id": "31",
      "name": "KOTA JAKARTA PUSAT"
    },
    {
      "id": "3174",
      "province_id": "31",
      "name": "KOTA JAKARTA BARAT"
    },
    {
      "id": "3175",
      "province_id": "31",
      "name": "KOTA JAKARTA UTARA"
    }
  ]