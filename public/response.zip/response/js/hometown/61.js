[
    {
      "id": "6101",
      "province_id": "61",
      "name": "KABUPATEN SAMBAS"
    },
    {
      "id": "6102",
      "province_id": "61",
      "name": "KABUPATEN BENGKAYANG"
    },
    {
      "id": "6103",
      "province_id": "61",
      "name": "KABUPATEN LANDAK"
    },
    {
      "id": "6104",
      "province_id": "61",
      "name": "KABUPATEN MEMPAWAH"
    },
    {
      "id": "6105",
      "province_id": "61",
      "name": "KABUPATEN SANGGAU"
    },
    {
      "id": "6106",
      "province_id": "61",
      "name": "KABUPATEN KETAPANG"
    },
    {
      "id": "6107",
      "province_id": "61",
      "name": "KABUPATEN SINTANG"
    },
    {
      "id": "6108",
      "province_id": "61",
      "name": "KABUPATEN KAPUAS HULU"
    },
    {
      "id": "6109",
      "province_id": "61",
      "name": "KABUPATEN SEKADAU"
    },
    {
      "id": "6110",
      "province_id": "61",
      "name": "KABUPATEN MELAWI"
    },
    {
      "id": "6111",
      "province_id": "61",
      "name": "KABUPATEN KAYONG UTARA"
    },
    {
      "id": "6112",
      "province_id": "61",
      "name": "KABUPATEN KUBU RAYA"
    },
    {
      "id": "6171",
      "province_id": "61",
      "name": "KOTA PONTIANAK"
    },
    {
      "id": "6172",
      "province_id": "61",
      "name": "KOTA SINGKAWANG"
    }
  ]