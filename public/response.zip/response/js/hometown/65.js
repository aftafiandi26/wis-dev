[
    {
      "id": "6501",
      "province_id": "65",
      "name": "KABUPATEN MALINAU"
    },
    {
      "id": "6502",
      "province_id": "65",
      "name": "KABUPATEN BULUNGAN"
    },
    {
      "id": "6503",
      "province_id": "65",
      "name": "KABUPATEN TANA TIDUNG"
    },
    {
      "id": "6504",
      "province_id": "65",
      "name": "KABUPATEN NUNUKAN"
    },
    {
      "id": "6571",
      "province_id": "65",
      "name": "KOTA TARAKAN"
    }
  ]