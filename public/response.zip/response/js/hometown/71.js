[
    {
      "id": "7101",
      "province_id": "71",
      "name": "KABUPATEN BOLAANG MONGONDOW"
    },
    {
      "id": "7102",
      "province_id": "71",
      "name": "KABUPATEN MINAHASA"
    },
    {
      "id": "7103",
      "province_id": "71",
      "name": "KABUPATEN KEPULAUAN SANGIHE"
    },
    {
      "id": "7104",
      "province_id": "71",
      "name": "KABUPATEN KEPULAUAN TALAUD"
    },
    {
      "id": "7105",
      "province_id": "71",
      "name": "KABUPATEN MINAHASA SELATAN"
    },
    {
      "id": "7106",
      "province_id": "71",
      "name": "KABUPATEN MINAHASA UTARA"
    },
    {
      "id": "7107",
      "province_id": "71",
      "name": "KABUPATEN BOLAANG MONGONDOW UTARA"
    },
    {
      "id": "7108",
      "province_id": "71",
      "name": "KABUPATEN SIAU TAGULANDANG BIARO"
    },
    {
      "id": "7109",
      "province_id": "71",
      "name": "KABUPATEN MINAHASA TENGGARA"
    },
    {
      "id": "7110",
      "province_id": "71",
      "name": "KABUPATEN BOLAANG MONGONDOW SELATAN"
    },
    {
      "id": "7111",
      "province_id": "71",
      "name": "KABUPATEN BOLAANG MONGONDOW TIMUR"
    },
    {
      "id": "7171",
      "province_id": "71",
      "name": "KOTA MANADO"
    },
    {
      "id": "7172",
      "province_id": "71",
      "name": "KOTA BITUNG"
    },
    {
      "id": "7173",
      "province_id": "71",
      "name": "KOTA TOMOHON"
    },
    {
      "id": "7174",
      "province_id": "71",
      "name": "KOTA KOTAMOBAGU"
    }
  ]