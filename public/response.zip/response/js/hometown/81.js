[
    {
      "id": "8101",
      "province_id": "81",
      "name": "KABUPATEN MALUKU TENGGARA BARAT"
    },
    {
      "id": "8102",
      "province_id": "81",
      "name": "KABUPATEN MALUKU TENGGARA"
    },
    {
      "id": "8103",
      "province_id": "81",
      "name": "KABUPATEN MALUKU TENGAH"
    },
    {
      "id": "8104",
      "province_id": "81",
      "name": "KABUPATEN BURU"
    },
    {
      "id": "8105",
      "province_id": "81",
      "name": "KABUPATEN KEPULAUAN ARU"
    },
    {
      "id": "8106",
      "province_id": "81",
      "name": "KABUPATEN SERAM BAGIAN BARAT"
    },
    {
      "id": "8107",
      "province_id": "81",
      "name": "KABUPATEN SERAM BAGIAN TIMUR"
    },
    {
      "id": "8108",
      "province_id": "81",
      "name": "KABUPATEN MALUKU BARAT DAYA"
    },
    {
      "id": "8109",
      "province_id": "81",
      "name": "KABUPATEN BURU SELATAN"
    },
    {
      "id": "8171",
      "province_id": "81",
      "name": "KOTA AMBON"
    },
    {
      "id": "8172",
      "province_id": "81",
      "name": "KOTA TUAL"
    }
  ]