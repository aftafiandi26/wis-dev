[
    {
      "id": "7201",
      "province_id": "72",
      "name": "KABUPATEN BANGGAI KEPULAUAN"
    },
    {
      "id": "7202",
      "province_id": "72",
      "name": "KABUPATEN BANGGAI"
    },
    {
      "id": "7203",
      "province_id": "72",
      "name": "KABUPATEN MOROWALI"
    },
    {
      "id": "7204",
      "province_id": "72",
      "name": "KABUPATEN POSO"
    },
    {
      "id": "7205",
      "province_id": "72",
      "name": "KABUPATEN DONGGALA"
    },
    {
      "id": "7206",
      "province_id": "72",
      "name": "KABUPATEN TOLI-TOLI"
    },
    {
      "id": "7207",
      "province_id": "72",
      "name": "KABUPATEN BUOL"
    },
    {
      "id": "7208",
      "province_id": "72",
      "name": "KABUPATEN PARIGI MOUTONG"
    },
    {
      "id": "7209",
      "province_id": "72",
      "name": "KABUPATEN TOJO UNA-UNA"
    },
    {
      "id": "7210",
      "province_id": "72",
      "name": "KABUPATEN SIGI"
    },
    {
      "id": "7211",
      "province_id": "72",
      "name": "KABUPATEN BANGGAI LAUT"
    },
    {
      "id": "7212",
      "province_id": "72",
      "name": "KABUPATEN MOROWALI UTARA"
    },
    {
      "id": "7271",
      "province_id": "72",
      "name": "KOTA PALU"
    }
  ]