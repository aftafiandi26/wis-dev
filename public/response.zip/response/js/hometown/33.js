[
    {
      "id": "3301",
      "province_id": "33",
      "name": "KABUPATEN CILACAP"
    },
    {
      "id": "3302",
      "province_id": "33",
      "name": "KABUPATEN BANYUMAS"
    },
    {
      "id": "3303",
      "province_id": "33",
      "name": "KABUPATEN PURBALINGGA"
    },
    {
      "id": "3304",
      "province_id": "33",
      "name": "KABUPATEN BANJARNEGARA"
    },
    {
      "id": "3305",
      "province_id": "33",
      "name": "KABUPATEN KEBUMEN"
    },
    {
      "id": "3306",
      "province_id": "33",
      "name": "KABUPATEN PURWOREJO"
    },
    {
      "id": "3307",
      "province_id": "33",
      "name": "KABUPATEN WONOSOBO"
    },
    {
      "id": "3308",
      "province_id": "33",
      "name": "KABUPATEN MAGELANG"
    },
    {
      "id": "3309",
      "province_id": "33",
      "name": "KABUPATEN BOYOLALI"
    },
    {
      "id": "3310",
      "province_id": "33",
      "name": "KABUPATEN KLATEN"
    },
    {
      "id": "3311",
      "province_id": "33",
      "name": "KABUPATEN SUKOHARJO"
    },
    {
      "id": "3312",
      "province_id": "33",
      "name": "KABUPATEN WONOGIRI"
    },
    {
      "id": "3313",
      "province_id": "33",
      "name": "KABUPATEN KARANGANYAR"
    },
    {
      "id": "3314",
      "province_id": "33",
      "name": "KABUPATEN SRAGEN"
    },
    {
      "id": "3315",
      "province_id": "33",
      "name": "KABUPATEN GROBOGAN"
    },
    {
      "id": "3316",
      "province_id": "33",
      "name": "KABUPATEN BLORA"
    },
    {
      "id": "3317",
      "province_id": "33",
      "name": "KABUPATEN REMBANG"
    },
    {
      "id": "3318",
      "province_id": "33",
      "name": "KABUPATEN PATI"
    },
    {
      "id": "3319",
      "province_id": "33",
      "name": "KABUPATEN KUDUS"
    },
    {
      "id": "3320",
      "province_id": "33",
      "name": "KABUPATEN JEPARA"
    },
    {
      "id": "3321",
      "province_id": "33",
      "name": "KABUPATEN DEMAK"
    },
    {
      "id": "3322",
      "province_id": "33",
      "name": "KABUPATEN SEMARANG"
    },
    {
      "id": "3323",
      "province_id": "33",
      "name": "KABUPATEN TEMANGGUNG"
    },
    {
      "id": "3324",
      "province_id": "33",
      "name": "KABUPATEN KENDAL"
    },
    {
      "id": "3325",
      "province_id": "33",
      "name": "KABUPATEN BATANG"
    },
    {
      "id": "3326",
      "province_id": "33",
      "name": "KABUPATEN PEKALONGAN"
    },
    {
      "id": "3327",
      "province_id": "33",
      "name": "KABUPATEN PEMALANG"
    },
    {
      "id": "3328",
      "province_id": "33",
      "name": "KABUPATEN TEGAL"
    },
    {
      "id": "3329",
      "province_id": "33",
      "name": "KABUPATEN BREBES"
    },
    {
      "id": "3371",
      "province_id": "33",
      "name": "KOTA MAGELANG"
    },
    {
      "id": "3372",
      "province_id": "33",
      "name": "KOTA SURAKARTA"
    },
    {
      "id": "3373",
      "province_id": "33",
      "name": "KOTA SALATIGA"
    },
    {
      "id": "3374",
      "province_id": "33",
      "name": "KOTA SEMARANG"
    },
    {
      "id": "3375",
      "province_id": "33",
      "name": "KOTA PEKALONGAN"
    },
    {
      "id": "3376",
      "province_id": "33",
      "name": "KOTA TEGAL"
    }
  ]