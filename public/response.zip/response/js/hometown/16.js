[
    {
      "id": "1601",
      "province_id": "16",
      "name": "KABUPATEN OGAN KOMERING ULU"
    },
    {
      "id": "1602",
      "province_id": "16",
      "name": "KABUPATEN OGAN KOMERING ILIR"
    },
    {
      "id": "1603",
      "province_id": "16",
      "name": "KABUPATEN MUARA ENIM"
    },
    {
      "id": "1604",
      "province_id": "16",
      "name": "KABUPATEN LAHAT"
    },
    {
      "id": "1605",
      "province_id": "16",
      "name": "KABUPATEN MUSI RAWAS"
    },
    {
      "id": "1606",
      "province_id": "16",
      "name": "KABUPATEN MUSI BANYUASIN"
    },
    {
      "id": "1607",
      "province_id": "16",
      "name": "KABUPATEN BANYU ASIN"
    },
    {
      "id": "1608",
      "province_id": "16",
      "name": "KABUPATEN OGAN KOMERING ULU SELATAN"
    },
    {
      "id": "1609",
      "province_id": "16",
      "name": "KABUPATEN OGAN KOMERING ULU TIMUR"
    },
    {
      "id": "1610",
      "province_id": "16",
      "name": "KABUPATEN OGAN ILIR"
    },
    {
      "id": "1611",
      "province_id": "16",
      "name": "KABUPATEN EMPAT LAWANG"
    },
    {
      "id": "1612",
      "province_id": "16",
      "name": "KABUPATEN PENUKAL ABAB LEMATANG ILIR"
    },
    {
      "id": "1613",
      "province_id": "16",
      "name": "KABUPATEN MUSI RAWAS UTARA"
    },
    {
      "id": "1671",
      "province_id": "16",
      "name": "KOTA PALEMBANG"
    },
    {
      "id": "1672",
      "province_id": "16",
      "name": "KOTA PRABUMULIH"
    },
    {
      "id": "1673",
      "province_id": "16",
      "name": "KOTA PAGAR ALAM"
    },
    {
      "id": "1674",
      "province_id": "16",
      "name": "KOTA LUBUKLINGGAU"
    }
  ]