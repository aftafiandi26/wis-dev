[
    {
        "id": "1201",
        "province_id": "12",
        "name": "KABUPATEN NIAS"
    },
    {
        "id": "1202",
        "province_id": "12",
        "name": "KABUPATEN MANDAILING NATAL"
    },
    {
        "id": "1203",
        "province_id": "12",
        "name": "KABUPATEN TAPANULI SELATAN"
    },
    {
        "id": "1204",
        "province_id": "12",
        "name": "KABUPATEN TAPANULI TENGAH"
    },
    {
        "id": "1205",
        "province_id": "12",
        "name": "KABUPATEN TAPANULI UTARA"
    },
    {
        "id": "1206",
        "province_id": "12",
        "name": "KABUPATEN TOBA SAMOSIR"
    },
    {
        "id": "1207",
        "province_id": "12",
        "name": "KABUPATEN LABUHAN BATU"
    },
    {
        "id": "1208",
        "province_id": "12",
        "name": "KABUPATEN ASAHAN"
    },
    {
        "id": "1209",
        "province_id": "12",
        "name": "KABUPATEN SIMALUNGUN"
    },
    {
        "id": "1210",
        "province_id": "12",
        "name": "KABUPATEN DAIRI"
    },
    {
        "id": "1211",
        "province_id": "12",
        "name": "KABUPATEN KARO"
    },
    {
        "id": "1212",
        "province_id": "12",
        "name": "KABUPATEN DELI SERDANG"
    },
    {
        "id": "1213",
        "province_id": "12",
        "name": "KABUPATEN LANGKAT"
    },
    {
        "id": "1214",
        "province_id": "12",
        "name": "KABUPATEN NIAS SELATAN"
    },
    {
        "id": "1215",
        "province_id": "12",
        "name": "KABUPATEN HUMBANG HASUNDUTAN"
    },
    {
        "id": "1216",
        "province_id": "12",
        "name": "KABUPATEN PAKPAK BHARAT"
    },
    {
        "id": "1217",
        "province_id": "12",
        "name": "KABUPATEN SAMOSIR"
    },
    {
        "id": "1218",
        "province_id": "12",
        "name": "KABUPATEN SERDANG BEDAGAI"
    },
    {
        "id": "1219",
        "province_id": "12",
        "name": "KABUPATEN BATU BARA"
    },
    {
        "id": "1220",
        "province_id": "12",
        "name": "KABUPATEN PADANG LAWAS UTARA"
    },
    {
        "id": "1221",
        "province_id": "12",
        "name": "KABUPATEN PADANG LAWAS"
    },
    {
        "id": "1222",
        "province_id": "12",
        "name": "KABUPATEN LABUHAN BATU SELATAN"
    },
    {
        "id": "1223",
        "province_id": "12",
        "name": "KABUPATEN LABUHAN BATU UTARA"
    },
    {
        "id": "1224",
        "province_id": "12",
        "name": "KABUPATEN NIAS UTARA"
    },
    {
        "id": "1225",
        "province_id": "12",
        "name": "KABUPATEN NIAS BARAT"
    },
    {
        "id": "1271",
        "province_id": "12",
        "name": "KOTA SIBOLGA"
    },
    {
        "id": "1272",
        "province_id": "12",
        "name": "KOTA TANJUNG BALAI"
    },
    {
        "id": "1273",
        "province_id": "12",
        "name": "KOTA PEMATANG SIANTAR"
    },
    {
        "id": "1274",
        "province_id": "12",
        "name": "KOTA TEBING TINGGI"
    },
    {
        "id": "1275",
        "province_id": "12",
        "name": "KOTA MEDAN"
    },
    {
        "id": "1276",
        "province_id": "12",
        "name": "KOTA BINJAI"
    },
    {
        "id": "1277",
        "province_id": "12",
        "name": "KOTA PADANGSIDIMPUAN"
    },
    {
        "id": "1278",
        "province_id": "12",
        "name": "KOTA GUNUNGSITOLI"
    }
] 