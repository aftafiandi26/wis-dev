[
    {
      "id": "8201",
      "province_id": "82",
      "name": "KABUPATEN HALMAHERA BARAT"
    },
    {
      "id": "8202",
      "province_id": "82",
      "name": "KABUPATEN HALMAHERA TENGAH"
    },
    {
      "id": "8203",
      "province_id": "82",
      "name": "KABUPATEN KEPULAUAN SULA"
    },
    {
      "id": "8204",
      "province_id": "82",
      "name": "KABUPATEN HALMAHERA SELATAN"
    },
    {
      "id": "8205",
      "province_id": "82",
      "name": "KABUPATEN HALMAHERA UTARA"
    },
    {
      "id": "8206",
      "province_id": "82",
      "name": "KABUPATEN HALMAHERA TIMUR"
    },
    {
      "id": "8207",
      "province_id": "82",
      "name": "KABUPATEN PULAU MOROTAI"
    },
    {
      "id": "8208",
      "province_id": "82",
      "name": "KABUPATEN PULAU TALIABU"
    },
    {
      "id": "8271",
      "province_id": "82",
      "name": "KOTA TERNATE"
    },
    {
      "id": "8272",
      "province_id": "82",
      "name": "KOTA TIDORE KEPULAUAN"
    }
  ]