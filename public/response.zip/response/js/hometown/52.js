[
    {
      "id": "5201",
      "province_id": "52",
      "name": "KABUPATEN LOMBOK BARAT"
    },
    {
      "id": "5202",
      "province_id": "52",
      "name": "KABUPATEN LOMBOK TENGAH"
    },
    {
      "id": "5203",
      "province_id": "52",
      "name": "KABUPATEN LOMBOK TIMUR"
    },
    {
      "id": "5204",
      "province_id": "52",
      "name": "KABUPATEN SUMBAWA"
    },
    {
      "id": "5205",
      "province_id": "52",
      "name": "KABUPATEN DOMPU"
    },
    {
      "id": "5206",
      "province_id": "52",
      "name": "KABUPATEN BIMA"
    },
    {
      "id": "5207",
      "province_id": "52",
      "name": "KABUPATEN SUMBAWA BARAT"
    },
    {
      "id": "5208",
      "province_id": "52",
      "name": "KABUPATEN LOMBOK UTARA"
    },
    {
      "id": "5271",
      "province_id": "52",
      "name": "KOTA MATARAM"
    },
    {
      "id": "5272",
      "province_id": "52",
      "name": "KOTA BIMA"
    }
  ]