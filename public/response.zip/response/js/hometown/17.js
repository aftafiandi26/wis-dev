[
    {
      "id": "1701",
      "province_id": "17",
      "name": "KABUPATEN BENGKULU SELATAN"
    },
    {
      "id": "1702",
      "province_id": "17",
      "name": "KABUPATEN REJANG LEBONG"
    },
    {
      "id": "1703",
      "province_id": "17",
      "name": "KABUPATEN BENGKULU UTARA"
    },
    {
      "id": "1704",
      "province_id": "17",
      "name": "KABUPATEN KAUR"
    },
    {
      "id": "1705",
      "province_id": "17",
      "name": "KABUPATEN SELUMA"
    },
    {
      "id": "1706",
      "province_id": "17",
      "name": "KABUPATEN MUKOMUKO"
    },
    {
      "id": "1707",
      "province_id": "17",
      "name": "KABUPATEN LEBONG"
    },
    {
      "id": "1708",
      "province_id": "17",
      "name": "KABUPATEN KEPAHIANG"
    },
    {
      "id": "1709",
      "province_id": "17",
      "name": "KABUPATEN BENGKULU TENGAH"
    },
    {
      "id": "1771",
      "province_id": "17",
      "name": "KOTA BENGKULU"
    }
  ]