[
    {
      "id": "9101",
      "province_id": "91",
      "name": "KABUPATEN FAKFAK"
    },
    {
      "id": "9102",
      "province_id": "91",
      "name": "KABUPATEN KAIMANA"
    },
    {
      "id": "9103",
      "province_id": "91",
      "name": "KABUPATEN TELUK WONDAMA"
    },
    {
      "id": "9104",
      "province_id": "91",
      "name": "KABUPATEN TELUK BINTUNI"
    },
    {
      "id": "9105",
      "province_id": "91",
      "name": "KABUPATEN MANOKWARI"
    },
    {
      "id": "9106",
      "province_id": "91",
      "name": "KABUPATEN SORONG SELATAN"
    },
    {
      "id": "9107",
      "province_id": "91",
      "name": "KABUPATEN SORONG"
    },
    {
      "id": "9108",
      "province_id": "91",
      "name": "KABUPATEN RAJA AMPAT"
    },
    {
      "id": "9109",
      "province_id": "91",
      "name": "KABUPATEN TAMBRAUW"
    },
    {
      "id": "9110",
      "province_id": "91",
      "name": "KABUPATEN MAYBRAT"
    },
    {
      "id": "9111",
      "province_id": "91",
      "name": "KABUPATEN MANOKWARI SELATAN"
    },
    {
      "id": "9112",
      "province_id": "91",
      "name": "KABUPATEN PEGUNUNGAN ARFAK"
    },
    {
      "id": "9171",
      "province_id": "91",
      "name": "KOTA SORONG"
    }
  ]