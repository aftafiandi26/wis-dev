[
    {
      "id": "6301",
      "province_id": "63",
      "name": "KABUPATEN TANAH LAUT"
    },
    {
      "id": "6302",
      "province_id": "63",
      "name": "KABUPATEN KOTA BARU"
    },
    {
      "id": "6303",
      "province_id": "63",
      "name": "KABUPATEN BANJAR"
    },
    {
      "id": "6304",
      "province_id": "63",
      "name": "KABUPATEN BARITO KUALA"
    },
    {
      "id": "6305",
      "province_id": "63",
      "name": "KABUPATEN TAPIN"
    },
    {
      "id": "6306",
      "province_id": "63",
      "name": "KABUPATEN HULU SUNGAI SELATAN"
    },
    {
      "id": "6307",
      "province_id": "63",
      "name": "KABUPATEN HULU SUNGAI TENGAH"
    },
    {
      "id": "6308",
      "province_id": "63",
      "name": "KABUPATEN HULU SUNGAI UTARA"
    },
    {
      "id": "6309",
      "province_id": "63",
      "name": "KABUPATEN TABALONG"
    },
    {
      "id": "6310",
      "province_id": "63",
      "name": "KABUPATEN TANAH BUMBU"
    },
    {
      "id": "6311",
      "province_id": "63",
      "name": "KABUPATEN BALANGAN"
    },
    {
      "id": "6371",
      "province_id": "63",
      "name": "KOTA BANJARMASIN"
    },
    {
      "id": "6372",
      "province_id": "63",
      "name": "KOTA BANJAR BARU"
    }
  ]