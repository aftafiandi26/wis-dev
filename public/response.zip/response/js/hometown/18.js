[
    {
      "id": "1801",
      "province_id": "18",
      "name": "KABUPATEN LAMPUNG BARAT"
    },
    {
      "id": "1802",
      "province_id": "18",
      "name": "KABUPATEN TANGGAMUS"
    },
    {
      "id": "1803",
      "province_id": "18",
      "name": "KABUPATEN LAMPUNG SELATAN"
    },
    {
      "id": "1804",
      "province_id": "18",
      "name": "KABUPATEN LAMPUNG TIMUR"
    },
    {
      "id": "1805",
      "province_id": "18",
      "name": "KABUPATEN LAMPUNG TENGAH"
    },
    {
      "id": "1806",
      "province_id": "18",
      "name": "KABUPATEN LAMPUNG UTARA"
    },
    {
      "id": "1807",
      "province_id": "18",
      "name": "KABUPATEN WAY KANAN"
    },
    {
      "id": "1808",
      "province_id": "18",
      "name": "KABUPATEN TULANGBAWANG"
    },
    {
      "id": "1809",
      "province_id": "18",
      "name": "KABUPATEN PESAWARAN"
    },
    {
      "id": "1810",
      "province_id": "18",
      "name": "KABUPATEN PRINGSEWU"
    },
    {
      "id": "1811",
      "province_id": "18",
      "name": "KABUPATEN MESUJI"
    },
    {
      "id": "1812",
      "province_id": "18",
      "name": "KABUPATEN TULANG BAWANG BARAT"
    },
    {
      "id": "1813",
      "province_id": "18",
      "name": "KABUPATEN PESISIR BARAT"
    },
    {
      "id": "1871",
      "province_id": "18",
      "name": "KOTA BANDAR LAMPUNG"
    },
    {
      "id": "1872",
      "province_id": "18",
      "name": "KOTA METRO"
    }
  ]