[
    {
      "id": "5301",
      "province_id": "53",
      "name": "KABUPATEN SUMBA BARAT"
    },
    {
      "id": "5302",
      "province_id": "53",
      "name": "KABUPATEN SUMBA TIMUR"
    },
    {
      "id": "5303",
      "province_id": "53",
      "name": "KABUPATEN KUPANG"
    },
    {
      "id": "5304",
      "province_id": "53",
      "name": "KABUPATEN TIMOR TENGAH SELATAN"
    },
    {
      "id": "5305",
      "province_id": "53",
      "name": "KABUPATEN TIMOR TENGAH UTARA"
    },
    {
      "id": "5306",
      "province_id": "53",
      "name": "KABUPATEN BELU"
    },
    {
      "id": "5307",
      "province_id": "53",
      "name": "KABUPATEN ALOR"
    },
    {
      "id": "5308",
      "province_id": "53",
      "name": "KABUPATEN LEMBATA"
    },
    {
      "id": "5309",
      "province_id": "53",
      "name": "KABUPATEN FLORES TIMUR"
    },
    {
      "id": "5310",
      "province_id": "53",
      "name": "KABUPATEN SIKKA"
    },
    {
      "id": "5311",
      "province_id": "53",
      "name": "KABUPATEN ENDE"
    },
    {
      "id": "5312",
      "province_id": "53",
      "name": "KABUPATEN NGADA"
    },
    {
      "id": "5313",
      "province_id": "53",
      "name": "KABUPATEN MANGGARAI"
    },
    {
      "id": "5314",
      "province_id": "53",
      "name": "KABUPATEN ROTE NDAO"
    },
    {
      "id": "5315",
      "province_id": "53",
      "name": "KABUPATEN MANGGARAI BARAT"
    },
    {
      "id": "5316",
      "province_id": "53",
      "name": "KABUPATEN SUMBA TENGAH"
    },
    {
      "id": "5317",
      "province_id": "53",
      "name": "KABUPATEN SUMBA BARAT DAYA"
    },
    {
      "id": "5318",
      "province_id": "53",
      "name": "KABUPATEN NAGEKEO"
    },
    {
      "id": "5319",
      "province_id": "53",
      "name": "KABUPATEN MANGGARAI TIMUR"
    },
    {
      "id": "5320",
      "province_id": "53",
      "name": "KABUPATEN SABU RAIJUA"
    },
    {
      "id": "5321",
      "province_id": "53",
      "name": "KABUPATEN MALAKA"
    },
    {
      "id": "5371",
      "province_id": "53",
      "name": "KOTA KUPANG"
    }
  ]