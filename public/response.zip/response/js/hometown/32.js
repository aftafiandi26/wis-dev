[
    {
      "id": "3201",
      "province_id": "32",
      "name": "KABUPATEN BOGOR"
    },
    {
      "id": "3202",
      "province_id": "32",
      "name": "KABUPATEN SUKABUMI"
    },
    {
      "id": "3203",
      "province_id": "32",
      "name": "KABUPATEN CIANJUR"
    },
    {
      "id": "3204",
      "province_id": "32",
      "name": "KABUPATEN BANDUNG"
    },
    {
      "id": "3205",
      "province_id": "32",
      "name": "KABUPATEN GARUT"
    },
    {
      "id": "3206",
      "province_id": "32",
      "name": "KABUPATEN TASIKMALAYA"
    },
    {
      "id": "3207",
      "province_id": "32",
      "name": "KABUPATEN CIAMIS"
    },
    {
      "id": "3208",
      "province_id": "32",
      "name": "KABUPATEN KUNINGAN"
    },
    {
      "id": "3209",
      "province_id": "32",
      "name": "KABUPATEN CIREBON"
    },
    {
      "id": "3210",
      "province_id": "32",
      "name": "KABUPATEN MAJALENGKA"
    },
    {
      "id": "3211",
      "province_id": "32",
      "name": "KABUPATEN SUMEDANG"
    },
    {
      "id": "3212",
      "province_id": "32",
      "name": "KABUPATEN INDRAMAYU"
    },
    {
      "id": "3213",
      "province_id": "32",
      "name": "KABUPATEN SUBANG"
    },
    {
      "id": "3214",
      "province_id": "32",
      "name": "KABUPATEN PURWAKARTA"
    },
    {
      "id": "3215",
      "province_id": "32",
      "name": "KABUPATEN KARAWANG"
    },
    {
      "id": "3216",
      "province_id": "32",
      "name": "KABUPATEN BEKASI"
    },
    {
      "id": "3217",
      "province_id": "32",
      "name": "KABUPATEN BANDUNG BARAT"
    },
    {
      "id": "3218",
      "province_id": "32",
      "name": "KABUPATEN PANGANDARAN"
    },
    {
      "id": "3271",
      "province_id": "32",
      "name": "KOTA BOGOR"
    },
    {
      "id": "3272",
      "province_id": "32",
      "name": "KOTA SUKABUMI"
    },
    {
      "id": "3273",
      "province_id": "32",
      "name": "KOTA BANDUNG"
    },
    {
      "id": "3274",
      "province_id": "32",
      "name": "KOTA CIREBON"
    },
    {
      "id": "3275",
      "province_id": "32",
      "name": "KOTA BEKASI"
    },
    {
      "id": "3276",
      "province_id": "32",
      "name": "KOTA DEPOK"
    },
    {
      "id": "3277",
      "province_id": "32",
      "name": "KOTA CIMAHI"
    },
    {
      "id": "3278",
      "province_id": "32",
      "name": "KOTA TASIKMALAYA"
    },
    {
      "id": "3279",
      "province_id": "32",
      "name": "KOTA BANJAR"
    }
  ]