@extends('layout')

@section('title')
    Summary Working on Weekends
@stop

@section('top')
    @include('assets_css_1')
    @include('assets_css_2')
    @include('assets_css_3')
    @include('assets_css_4')
    @include('asset_select2')
@stop

@section('navbar')
    @include('navbar_top')
    @include('navbar_left', [
        'workingWeekends01' => 'active'
    ])
@stop
@push('style')
<style>
   
</style>
@endpush
@section('body')
<div class="row">
    <div class="col-lg-12"><h1 class="page-header">Summary Weekend Crew</h1>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <table class="table table-condensed table-hover table-striped table-bordered" id="tables" width="100%">
            <thead>
                <tr>
                    <th style="with: 15px;">No</th>
                    <th>Employes</th>
                    <th>Position</th>
                    <th>Project</th>
                    <th>Started</th>
                    <th>Ended</th>
                    <th>Time</th>
                    <th>Status</th>
                </tr>
            </thead>
        </table>
    </div>
</div>

<div class="modal fade" id="modalDate" tabindex="-1" role="dialog" aria-labelledby="showModalLabel" aria-hidden="true"  style="width: 90%;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" id="modal-content-insert">
            <!--  -->
        </div>
    </div>
</div>

@stop

@section('bottom')
    @include('assets_script_1')
    @include('assets_script_2')
    @include('assets_script_3')
    @include('assets_script_7')
@stop

@section('script')
$('table#tables').DataTable({
    processing: true, 
    responsive: true, 
   
    ajax: '{{ route('working-on-weekends/summary/index/data') }}',
    columns: [
            {"data": "DT_Row_Index", orderable: false, searchable : false},   
            {"data": "user_id"},
            {"data": "position"},
            {"data": "project"},
            {"data": "start"},
            {"data": "end"},
            {"data": "time"},
            {"data": "approved"},
        ]
});
@stop
