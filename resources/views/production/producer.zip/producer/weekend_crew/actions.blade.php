<a class="btn btn-xs btn-default" data-toggle="modal" data-target="#modalApproved" data-role="{{ route('producer/weekend-crew/detail', $id) }}" title="detail" id="detail">weekend crew</a>
